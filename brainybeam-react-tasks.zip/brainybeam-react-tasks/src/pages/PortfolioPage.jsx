import React from 'react'

const projects = [
  { id:1, title:'E-Commerce Frontend', link:'#', desc:'Product listing, cart, checkout with React + Context.'},
  { id:2, title:'Real-time Chat', link:'#', desc:'Socket.io chat UI with rooms and typing indicators.'},
  { id:3, title:'Recipe Generator', link:'#', desc:'Suggests recipes from leftover ingredients.'},
]

export default function PortfolioPage(){
  return (
    <div className="container">
      <header className="card" style={{display:'flex', alignItems:'center', gap:'1rem'}}>
        <img src="https://avatars.githubusercontent.com/u/9919?s=80&v=4" width="64" height="64" style={{borderRadius:'50%'}} alt="" />
        <div>
          <h1 style={{margin:'0 0 .25rem'}}>Smit Bapodariya</h1>
          <p style={{margin:0}}>Full‑Stack Developer • MERN • React • Node</p>
          <div style={{display:'flex', gap:'.5rem', marginTop:'.5rem'}}>
            <a className="btn" href="https://github.com/" target="_blank" rel="noreferrer">GitHub</a>
            <a className="btn secondary" href="mailto:you@example.com">Contact</a>
          </div>
        </div>
      </header>

      <section style={{marginTop:'1rem'}}>
        <h2>Skills</h2>
        <div className="card">
          JavaScript, TypeScript, React, Redux/Context, Node.js, Express, MongoDB, REST API, HTML, CSS, Git
        </div>
      </section>

      <section style={{marginTop:'1rem'}}>
        <h2>Projects</h2>
        <div className="grid">
          {projects.map(p => (
            <article className="card" key={p.id}>
              <h3 style={{marginTop:0}}>{p.title}</h3>
              <p>{p.desc}</p>
              <a className="btn" href={p.link} onClick={(e)=>e.preventDefault()}>View</a>
            </article>
          ))}
        </div>
      </section>

      <section style={{marginTop:'1rem'}}>
        <h2>About</h2>
        <div className="card">
          <p>I enjoy building clean, accessible UIs and scalable APIs. Open to internships and full-time roles.</p>
        </div>
      </section>
    </div>
  )
}
