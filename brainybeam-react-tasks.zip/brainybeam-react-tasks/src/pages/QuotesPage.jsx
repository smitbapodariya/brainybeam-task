import React, { useEffect, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'

const RANDOM_API = 'https://api.quotable.io/random' // public random quote API
const POST_API = 'https://jsonplaceholder.typicode.com/posts' // demo POST API

export default function QuotesPage(){
  const [quote, setQuote] = useState(null)
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const { addPost, posts } = useApp()

  const loadQuote = async () => {
    setLoading(true)
    setMessage('')
    try{
      const res = await fetch(RANDOM_API)
      const data = await res.json()
      setQuote({ text: data.content, author: data.author })
    }catch(err){
      setMessage('Failed to fetch quote: ' + (err.message || 'unknown error'))
    }finally{
      setLoading(false)
    }
  }

  const postCurrentQuote = async () => {
    if (!quote) return
    setMessage('')
    try{
      const res = await fetch(POST_API, {
        method:'POST',
        headers:{ 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: quote.author || 'Anonymous',
          body: quote.text,
          userId: 1
        })
      })
      const created = await res.json()
      setMessage('Posted to API with id: ' + created.id)
    }catch(err){
      setMessage('Failed to create post: ' + (err.message || 'unknown error'))
    }
  }

  const saveLocalPost = () => {
    if (!quote) return
    const p = { id: Date.now(), title: quote.author || 'Anonymous', body: quote.text }
    addPost(p)
    setMessage('Saved to local context posts ✓')
  }

  useEffect(() => { loadQuote() }, [])

  return (
    <div className="container">
      <h1>Quotes</h1>
      <div className="card">
        {loading && <p>Loading…</p>}
        {!loading && quote && (
          <>
            <blockquote style={{fontSize:'1.25rem'}}>&ldquo;{quote.text}&rdquo;</blockquote>
            <p style={{opacity:.8, marginTop:'.25rem'}}>— {quote.author || 'Unknown'}</p>
            <div style={{display:'flex', gap:'.5rem', marginTop:'1rem'}}>
              <button className="btn" onClick={loadQuote}>New Quote</button>
              <button className="btn secondary" onClick={postCurrentQuote}>Create Post from Quote (API)</button>
              <button className="btn" onClick={saveLocalPost}>Save to Local Posts</button>
            </div>
            {message && <p style={{marginTop:'.5rem'}}>{message}</p>}
          </>
        )}
      </div>

      <h2 style={{marginTop:'1.5rem'}}>Local Posts</h2>
      <div className="grid">
        {posts.map(p => (
          <div className="card" key={p.id}>
            <h3 style={{marginTop:0}}>{p.title}</h3>
            <p>{p.body}</p>
          </div>
        ))}
        {posts.length === 0 && <p>No local posts yet. Save one from a quote!</p>}
      </div>
    </div>
  )
}
