import React, { useState } from 'react'
import CalcButton from '../components/CalcButton.jsx'

const KEYS = [
  '7','8','9','/',
  '4','5','6','*',
  '1','2','3','-',
  '0','.','=','+',
]

export default function CalculatorPage(){
  const [display, setDisplay] = useState('0')

  const onKey = (k) => {
    if (k === 'C') { setDisplay('0'); return }
    if (k === '=') {
      try {
        // Safe-ish evaluation: allow digits, ops and dot only
        if (!/^[0-9+\-*/.()\s]+$/.test(display)) throw new Error('Invalid expression')
        // evaluate
        const result = Function('return ' + display)()
        setDisplay(String(result))
      } catch {
        setDisplay('Error')
      }
      return
    }
    // Append
    setDisplay((d) => (d === '0' ? k : d + k))
  }

  return (
    <div className="container">
      <h1>Simple Calculator</h1>
      <div className="calc">
        <div className="calc-display">{display}</div>
        <div style={{display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:'.5rem', marginBottom:'.5rem'}}>
          <button className="calc-btn wide" onClick={() => setDisplay('0')}>C</button>
          <button className="calc-btn wide" onClick={() => setDisplay(display.slice(0, -1) || '0')}>⌫</button>
        </div>
        <div className="calc-grid">
          {KEYS.map(k => (
            <CalcButton key={k} label={k} onClick={onKey} />
          ))}
        </div>
      </div>
      <p style={{opacity:.8}}>Buttons are rendered using a reusable <code>CalcButton</code> component.</p>
    </div>
  )
}
