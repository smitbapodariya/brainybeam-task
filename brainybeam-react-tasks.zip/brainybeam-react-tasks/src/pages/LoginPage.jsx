import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function LoginPage(){
  const { login, isAuthenticated } = useAuth()
  const [username, setUsername] = useState('smit')
  const [password, setPassword] = useState('123456')
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const location = useLocation()
  const from = '/protected'

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    try{
      await login(username, password)
      navigate(from, { replace: true })
    }catch(err){
      setError(err.message || 'Login failed')
    }
  }

  if (isAuthenticated) {
    // small UX: already logged-in users go straight to protected page
    navigate(from)
    return null
  }

  return (
    <div className="container">
      <h1>Login</h1>
      <p>Use any username and password to simulate authentication.</p>
      {error && <p style={{color:'salmon'}}>{error}</p>}
      <form onSubmit={handleSubmit} className="card" style={{maxWidth:480}}>
        <div>
          <label>Username</label>
          <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="username" />
        </div>
        <div>
          <label>Password</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" />
        </div>
        <div style={{display:'flex', gap:'.5rem', marginTop:'1rem'}}>
          <button className="btn" type="submit">Login</button>
          <button className="btn secondary" type="reset" onClick={()=>{setUsername(''); setPassword('')}}>Clear</button>
        </div>
      </form>
      <p>After login you will be redirected to the <code>/protected</code> route.</p>
    </div>
  )
}
