import React from 'react'
import { useAuth } from '../context/AuthContext.jsx'

export default function ProtectedPage(){
  const { user } = useAuth()
  return (
    <div className="container">
      <h1>Protected Route</h1>
      <div className="card">
        <p>Welcome to the protected area, <strong>{user?.username}</strong>! 🎉</p>
        <p>This page is accessible only after authentication.</p>
      </div>
    </div>
  )
}
