import React from 'react'
import { useApp } from '../context/AppContext.jsx'

function ChildCounter(){
  const { count, increment, decrement } = useApp()
  return (
    <div className="card">
      <h3>Counter (global via Context)</h3>
      <p style={{fontSize:'1.5rem'}}>{count}</p>
      <div style={{display:'flex', gap:'.5rem'}}>
        <button className="btn" onClick={increment}>Increment</button>
        <button className="btn secondary" onClick={decrement}>Decrement</button>
      </div>
    </div>
  )
}

function ThemeBox(){
  const { theme, toggleTheme } = useApp()
  const boxStyle = {
    padding:'1rem',
    borderRadius:'.75rem',
    border:'1px solid #223',
    background: theme === 'dark' ? '#0b1533' : '#f5f7ff',
    color: theme === 'dark' ? '#eaf2ff' : '#0b1533'
  }
  return (
    <div className="card">
      <h3>Theme</h3>
      <p>Current theme: <strong>{theme}</strong></p>
      <div style={boxStyle}>This box changes with theme context.</div>
      <button className="btn" style={{marginTop:'.75rem'}} onClick={toggleTheme}>Toggle Theme</button>
    </div>
  )
}

export default function ContextDemoPage(){
  const { posts } = useApp()
  return (
    <div className="container">
      <h1>React Context Demo</h1>
      <p>This page demonstrates global state using <code>React.createContext</code> for theme, counter and locally saved posts.</p>
      <div className="grid">
        <ChildCounter />
        <ThemeBox />
        <div className="card">
          <h3>Posts Count</h3>
          <p>Your app currently has <strong>{posts.length}</strong> post(s) saved in global context from the Quotes page.</p>
          <p>Context lets any component read/write this without prop drilling.</p>
        </div>
      </div>
    </div>
  )
}
