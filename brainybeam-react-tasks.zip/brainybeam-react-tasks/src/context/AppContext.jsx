import React, { createContext, useContext, useMemo, useState } from 'react'

const AppContext = createContext(null)

export const AppProvider = ({ children }) => {
  const [theme, setTheme] = useState('dark') // 'light' | 'dark'
  const [count, setCount] = useState(0)
  const [posts, setPosts] = useState([]) // used by Quotes task to store local posts

  const toggleTheme = () => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))
  const increment = () => setCount((c) => c + 1)
  const decrement = () => setCount((c) => c - 1)
  const addPost = (p) => setPosts((prev) => [p, ...prev])

  const value = useMemo(
    () => ({ theme, toggleTheme, count, increment, decrement, posts, addPost }),
    [theme, count, posts]
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export const useApp = () => useContext(AppContext)
