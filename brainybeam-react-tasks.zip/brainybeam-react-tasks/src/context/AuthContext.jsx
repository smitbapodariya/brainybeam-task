import React, { createContext, useContext, useEffect, useState } from 'react'

const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(null)

  useEffect(() => {
    const t = localStorage.getItem('bb_token')
    const u = localStorage.getItem('bb_user')
    if (t && u) {
      setToken(t)
      setUser(JSON.parse(u))
    }
  }, [])

  const login = async (username, password) => {
    // Simulated login. For real apps, hit your backend here.
    if (!username || !password) throw new Error('Username and password required')
    const fakeToken = 'demo-token-' + Math.random().toString(36).slice(2)
    setToken(fakeToken)
    setUser({ username })
    localStorage.setItem('bb_token', fakeToken)
    localStorage.setItem('bb_user', JSON.stringify({ username }))
    return true
  }

  const logout = () => {
    setToken(null)
    setUser(null)
    localStorage.removeItem('bb_token')
    localStorage.removeItem('bb_user')
  }

  const value = {
    user,
    token,
    isAuthenticated: Boolean(token),
    login,
    logout,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
