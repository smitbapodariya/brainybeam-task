import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import NavBar from './components/NavBar.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'
import { AuthProvider } from './context/AuthContext.jsx'
import { AppProvider } from './context/AppContext.jsx'
import LoginPage from './pages/LoginPage.jsx'
import ProtectedPage from './pages/ProtectedPage.jsx'
import QuotesPage from './pages/QuotesPage.jsx'
import ContextDemoPage from './pages/ContextDemoPage.jsx'
import CalculatorPage from './pages/CalculatorPage.jsx'
import PortfolioPage from './pages/PortfolioPage.jsx'

export default function App(){
  return (
    <AuthProvider>
      <AppProvider>
        <NavBar />
        <Routes>
          <Route path="/" element={<Navigate to="/portfolio" replace />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/protected" element={
            <ProtectedRoute>
              <ProtectedPage />
            </ProtectedRoute>
          } />
          <Route path="/quotes" element={<QuotesPage />} />
          <Route path="/context" element={<ContextDemoPage />} />
          <Route path="/calculator" element={<CalculatorPage />} />
          <Route path="/portfolio" element={<PortfolioPage />} />
          <Route path="*" element={<div className="container"><h1>404</h1><p>Not found</p></div>} />
        </Routes>
        <div className="footer">BrainyBeam React Tasks • Auth, Quotes, Context, Calculator, Portfolio</div>
      </AppProvider>
    </AuthProvider>
  )
}
