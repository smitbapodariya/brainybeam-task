import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function NavBar(){
  const { isAuthenticated, user, logout } = useAuth()
  const navigate = useNavigate()
  const doLogout = () => { logout(); navigate('/login') }

  const linkClass = ({ isActive }) => isActive ? 'active' : undefined

  return (
    <div className="nav">
      <div className="container nav-inner">
        <div style={{display:'flex', gap:'.25rem', flexWrap:'wrap'}}>
          <NavLink to="/portfolio" className={linkClass}>Portfolio</NavLink>
          <NavLink to="/quotes" className={linkClass}>Quotes</NavLink>
          <NavLink to="/context" className={linkClass}>Context</NavLink>
          <NavLink to="/calculator" className={linkClass}>Calculator</NavLink>
          <NavLink to="/protected" className={linkClass}>Protected</NavLink>
        </div>
        <div style={{display:'flex', gap:'.5rem', alignItems:'center'}}>
          {isAuthenticated ? (
            <>
              <span>Hi, <strong>{user?.username}</strong></span>
              <button className="btn secondary" onClick={doLogout}>Logout</button>
            </>
          ) : (
            <NavLink to="/login" className={linkClass}>Login</NavLink>
          )}
        </div>
      </div>
    </div>
  )
}
