import React from 'react'

export default function CalcButton({ label, onClick, wide=false }){
  return (
    <button className={'calc-btn' + (wide ? ' wide' : '')} onClick={() => onClick(label)}>
      {label}
    </button>
  )
}
