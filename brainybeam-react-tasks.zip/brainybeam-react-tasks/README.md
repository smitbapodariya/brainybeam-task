
# BrainyBeam React Tasks

A single Vite + React app that covers all five tasks:

1) **Auth routing** – protected route `/protected` requires login.
2) **Quotes** – fetch random quote; post it to API (JSONPlaceholder) or save to local context.
3) **Context** – global context for theme, counter, and posts.
4) **Calculator** – simple calculator using a reusable button component.
5) **Portfolio page** – personal portfolio layout.

## Quick start

```bash
npm install
npm run dev
```

Open the URL printed by Vite (usually http://localhost:5173).

## Where things live

- `src/context/AuthContext.jsx` – fake auth with token in `localStorage`.
- `src/components/ProtectedRoute.jsx` – gate that redirects to `/login` when not authenticated.
- `src/pages/QuotesPage.jsx` – calls `https://api.quotable.io/random`, and can POST to `https://jsonplaceholder.typicode.com/posts`.
- `src/context/AppContext.jsx` – global state (theme, counter, posts).
- `src/pages/CalculatorPage.jsx` & `src/components/CalcButton.jsx` – calculator and reusable button.
- `src/pages/PortfolioPage.jsx` – portfolio content.
- `src/App.jsx` – routes + layout.

## Notes

- This is a learning scaffold. For production, replace the fake login with a real backend and more robust error handling/validation.
